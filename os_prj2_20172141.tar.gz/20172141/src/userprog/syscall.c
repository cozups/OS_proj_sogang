#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include <string.h>
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "filesys/off_t.h"

struct file
{
	struct inode *inode;        /* File's inode. */
	off_t pos;                  /* Current position. */
	bool deny_write;            /* Has file_deny_write() been called? */
};

struct lock mutex;
static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
	lock_init(&mutex);
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  /*printf ("system call!\n");
  thread_exit ();*/
  //printf("syscall : %d\n", *(uint32_t*)(f->esp));
  //hex_dump(f->esp, f->esp, 100, 1);
  int k;
  void *bf, *ptr;
  unsigned s;
  const char *fname;
  int size;
  switch(*(uint32_t*)(f->esp)){
    case SYS_HALT:
		halt();
		break;
    case SYS_EXIT:
  		if(!is_user_vaddr(f->esp+4)){
			exit(-1);
		}
		exit(*(int*)(f->esp+4));
		break;
    case SYS_EXEC:
  		if(!is_user_vaddr(f->esp+4)){
			exit(-1);
		}
		ptr = *(char**)(f->esp+4);
		f->eax = exec(ptr);
		break;
    case SYS_WAIT:
		if(!is_user_vaddr(f->esp+4)){
			exit(-1);
		}
		f->eax = wait(*(uint32_t*)(f->esp+4));
		break;
    case SYS_CREATE:
		if (!is_user_vaddr(f->esp + 4) || !is_user_vaddr(f->esp + 8)) exit(-1);
		fname = (const char *)(*(uint32_t*)(f->esp + 4));
		size = (unsigned)(*(uint32_t*)(f->esp + 8));
		f->eax = create(fname, size);
		break;
    case SYS_REMOVE:
		if (!is_user_vaddr(f->esp + 4)) exit(-1);
		fname = (const char *)(*(uint32_t*)(f->esp + 4));
		f->eax = remove(fname);
		break;
    case SYS_OPEN:
		if (!is_user_vaddr(f->esp + 4)) exit(-1);
		fname = (const char *)(*(uint32_t*)(f->esp + 4));
		f->eax = open(fname);
		break;
    case SYS_FILESIZE:
		if (!is_user_vaddr(f->esp + 4)) exit(-1);
		k = (int)(*(uint32_t*)(f->esp + 4));
		f->eax = filesize(k);
		break;
    case SYS_READ:
    	if(!is_user_vaddr(f->esp+4) || !is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12)){
		exit(-1);
		}
  		k = (int)(*(uint32_t*)(f->esp+4));
		bf = (void*)(*(uint32_t*)(f->esp+8));
		s = (unsigned)(*(uint32_t*)(f->esp+12));
  		f->eax = read(k, bf, s);
		break;
    case SYS_WRITE:
    	if(!is_user_vaddr(f->esp+4) || !is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12)){
			exit(-1);
		}
		k = (int)(*(uint32_t*)(f->esp+4));
		bf = (void*)(*(uint32_t*)(f->esp+8));
		s = (unsigned)(*(uint32_t*)(f->esp+12));
    	f->eax = write(k, bf, s);
  		break;
    case SYS_SEEK:
		if (!is_user_vaddr(f->esp + 4) || !is_user_vaddr(f->esp + 8)) exit(-1);
		k = (int)(*(uint32_t*)(f->esp + 4));
		s = (unsigned)(*(uint32_t*)(f->esp + 8));
		seek(k, s);
		break;
    case SYS_TELL:
		if (!is_user_vaddr(f->esp + 4)) exit(-1);
		k = (int)(*(uint32_t*)(f->esp + 4));
		f->eax = tell(k);
		break;
    case SYS_CLOSE:
		if (!is_user_vaddr(f->esp + 4)) exit(-1);
		k = (int)(*(uint32_t*)(f->esp + 4));
		close(k);
		break;
    case SYS_FIBONACCI:
		if(!is_user_vaddr(f->esp+4)){
			exit(-1);
		}
		k = (int)(*(uint32_t*)(f->esp+4));
		f->eax = fibonacci(k);
		break;
    case SYS_MAXFOURINT:
		if(!is_user_vaddr(f->esp+4) || !is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12) || !is_user_vaddr(f->esp+16)){
			exit(-1);
		}
		int a = (int)(*(uint32_t*)(f->esp+4));
		int b = (int)(*(uint32_t*)(f->esp+8));
		int c = (int)(*(uint32_t*)(f->esp+12));
		int d = (int)(*(uint32_t*)(f->esp+16));
		f->eax = max_of_four_int(a, b, c, d);
		break;
  }
}

void
halt (void) 
{
  shutdown_power_off();
}

void
exit (int status)
{
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_current()->exit_status = status;

  struct thread *temp;
  struct list_elem *cur = list_begin(&thread_current()->child_list);
  for (int i = 0; i < 128; i++) {
	  if (thread_current()->openfile[i] != NULL)
		  close(i);
  }
  while (cur != list_end(&thread_current()->child_list)) {
	  temp = list_entry(cur, struct thread, child_list_elem);
	  process_wait(temp->tid);
	  cur = list_next(cur);
  }
  thread_exit();
}

pid_t
exec (const char *file)
{
  return process_execute(file);
}

int
wait (pid_t pid)
{
  return process_wait(pid);
}

bool
create (const char *file, unsigned initial_size)
{
	if (!file) exit(-1);
	return filesys_create(file, initial_size);
}

bool
remove (const char *file)
{
	if (!file) exit(-1);
	return filesys_remove(file);
}

int
open (const char *file)
{
	int retVal = -1;
	if (!file) exit(-1);
	lock_acquire(&mutex);
	struct file* f_open = filesys_open(file);
	if(is_opened(file)) file_deny_write(f_open);
	if (f_open) {
		for (int i = 3; i < 128; i++) {
			if (thread_current()->openfile[i] == NULL) {
				thread_current()->openfile[i] = f_open;
				retVal = i;
				break;
			}
		}
	}
	lock_release(&mutex);
	return retVal;
}

int
filesize (int fd) 
{
	return file_length(thread_current()->openfile[fd]);
}

int
read (int fd, void *buffer, unsigned size)
{
  char c;
  int i, retVal = -1;
  if (!is_user_vaddr(buffer)) exit(-1);

  lock_acquire(&mutex);
  if(fd == 0){
   for(i = 0; i < size; i++){
     c= input_getc();
     memset(buffer+i, c, sizeof(char));
     if(c == '\0'|| c == '\n'){
       memset(buffer+i, '\0', sizeof(char));
       break;
     }
   }
   retVal = i;
 } 
 else if (fd > 2) {
	  if (!thread_current()->openfile[fd]) {
		  lock_release(&mutex);
		  exit(-1);
	  }
	 else retVal = file_read(thread_current()->openfile[fd], buffer, size);
 }
 lock_release(&mutex);
 return retVal;
}

int
write (int fd, const void *buffer, unsigned size)
{
	int retVal = -1;
	if (!is_user_vaddr(buffer)) exit(-1);

	lock_acquire(&mutex);
	if(fd == 1){
		putbuf(buffer, size);
		retVal = size;
	}
	else if (fd > 2){
		if (!thread_current()->openfile[fd]) {
			lock_release(&mutex);
			exit(-1);
		}
		//if (thread_current()->openfile[fd]->deny_write) file_deny_write(thread_current()->openfile[fd]);
		retVal = file_write(thread_current()->openfile[fd], buffer, size);
	}
	lock_release(&mutex);
	return retVal;
}

void
seek (int fd, unsigned position) 
{
	if (!thread_current()->openfile[fd]) exit(-1);
	return file_seek(thread_current()->openfile[fd], position);
}

unsigned
tell (int fd) 
{
	if (!thread_current()->openfile[fd]) exit(-1);
	return file_tell(thread_current()->openfile[fd]);
}

void
close (int fd)
{
	if (!thread_current()->openfile[fd]) exit(-1);
	file_close(thread_current()->openfile[fd]);
	thread_current()->openfile[fd] = NULL;
}

int fibonacci(int n){
  int a = 0, b = 1, res;
  if(n==0) return a;
  for(int i = 2; i<=n; i++){
    res = a+b;
    a = b;
    b = res;
  }
  return res;
}

int max_of_four_int(int a, int b, int c, int d){
  int max;
  max = a > b ? a : b;
  max = c > max? c : max;
  max = d > max? d : max;

  return max;
}

bool is_opened(const char *file) {
	const char *current = thread_name();
	if (strcmp(current, file) == 0 && thread_current()->status == THREAD_RUNNING)
		return true;
	else return false;
}
