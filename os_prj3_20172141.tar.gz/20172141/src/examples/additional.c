#include <stdio.h>
#include <syscall.h>
#include <stdlib.h>

int main(int argc, char **argv){
    int i;
    int a = atoi(argv[1]), b = atoi(argv[2]), c = atoi(argv[3]), d = atoi(argv[4]);

    int fibo = fibonacci(a);
    int max = max_of_four_int(a, b, c, d);
    printf("%d %d\n", fibo, max);
    return EXIT_SUCCESS;
}