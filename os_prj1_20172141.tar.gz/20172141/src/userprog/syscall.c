#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include <string.h>
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/vaddr.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  /*printf ("system call!\n");
  thread_exit ();*/
  //printf("syscall : %d\n", *(uint32_t*)(f->esp));
  //hex_dump(f->esp, f->esp, 100, 1);
  int k;
  void *bf, *ptr;
  unsigned s;
  switch(*(uint32_t*)(f->esp)){
    case SYS_HALT:
	halt();
	break;
    case SYS_EXIT:
  	if(!is_user_vaddr(f->esp+4)){
		exit(-1);
	}
	exit(*(int*)(f->esp+4));
	break;
    case SYS_EXEC:
  	if(!is_user_vaddr(f->esp+4)){
		exit(-1);
	}
  	ptr = *(char**)(f->esp+4);
  	f->eax = exec(ptr);
	break;
    case SYS_WAIT:
    if(!is_user_vaddr(f->esp+4)){
		exit(-1);
	  }
    f->eax = wait(*(uint32_t*)(f->esp+4));
	break;
    case SYS_CREATE:
	break;
    case SYS_REMOVE:
	break;
    case SYS_OPEN:
	break;
    case SYS_FILESIZE:
	break;
    case SYS_READ:
    	if(!is_user_vaddr(f->esp+4) || !is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12)){
		exit(-1);
	}
  	k = (int)(*(uint32_t*)(f->esp+4));
	bf = (void*)(*(uint32_t*)(f->esp+8));
	s = (unsigned)(*(uint32_t*)(f->esp+12));
  	f->eax = read(k, bf, s);
	break;
    case SYS_WRITE:
    	if(!is_user_vaddr(f->esp+4) || !is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12)){
		exit(-1);
	}
	k = (int)(*(uint32_t*)(f->esp+4));
	bf = (void*)(*(uint32_t*)(f->esp+8));
	s = (unsigned)(*(uint32_t*)(f->esp+12));
    	f->eax = write(k, bf, s);
  	break;
    case SYS_SEEK:
	break;
    case SYS_TELL:
	break;
    case SYS_CLOSE:
	break;
    case SYS_FIBONACCI:
    if(!is_user_vaddr(f->esp+4)){
		exit(-1);
	}
    k = (int)(*(uint32_t*)(f->esp+4));
    f->eax = fibonacci(k);
  break;
    case SYS_MAXFOURINT:
    if(!is_user_vaddr(f->esp+4) || !is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12) || !is_user_vaddr(f->esp+16)){
		exit(-1);
	}
    int a = (int)(*(uint32_t*)(f->esp+4));
    int b = (int)(*(uint32_t*)(f->esp+8));
    int c = (int)(*(uint32_t*)(f->esp+12));
    int d = (int)(*(uint32_t*)(f->esp+16));
    f->eax = max_of_four_int(a, b, c, d);
    break;
  }
}

void
halt (void) 
{
  shutdown_power_off();
}

void
exit (int status)
{
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_current()->exit_status = status;
  thread_exit();
}

pid_t
exec (const char *file)
{
  return process_execute(file);
}

int
wait (pid_t pid)
{
  return process_wait(pid);
}

bool
create (const char *file, unsigned initial_size)
{
  
}

bool
remove (const char *file)
{
  
}

int
open (const char *file)
{
  
}

int
filesize (int fd) 
{
  
}

int
read (int fd, void *buffer, unsigned size)
{
  char c;
  int i;
 if(fd == 0){
   for(i = 0; i<size; i++){
     c= input_getc();
     memset(buffer+i, c, sizeof(char));
     if(c == '\0'|| c == '\n'){
       memset(buffer+i, '\0', sizeof(char));
       break;
     }
   }
   return i;
 } 
 return -1;
}

int
write (int fd, const void *buffer, unsigned size)
{
  if(fd == 1){
    putbuf(buffer, size);
    return size;
  }
  return -1;
}

void
seek (int fd, unsigned position) 
{
  
}

unsigned
tell (int fd) 
{
  
}

void
close (int fd)
{

}

void check_vaddr(const void *v){
	if(!is_user_vaddr(v)){
		exit(-1);
	}
}

int fibonacci(int n){
  int a = 0, b = 1, res;
  if(n==0) return a;
  for(int i = 2; i<=n; i++){
    res = a+b;
    a = b;
    b = res;
  }
  return res;
}

int max_of_four_int(int a, int b, int c, int d){
  int max;
  max = a > b ? a : b;
  max = c > max? c : max;
  max = d > max? d : max;

  return max;
}
